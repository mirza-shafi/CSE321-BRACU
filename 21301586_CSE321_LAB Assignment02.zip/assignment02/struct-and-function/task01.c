#include <stdio.h>
typedef struct {
    int quantity;
    float unit_price;
} Item;

int main() {
    Item paratha, vegetable, water;
    int people;
    printf("Quantity of Paratha: ");
    scanf("%d", &paratha.quantity);
    printf("Unit Price: ");
    scanf("%f", &paratha.unit_price);

    printf("Quantity of Vegetables: ");
    scanf("%d", &vegetable.quantity);
    printf("Unit Price: ");
    scanf("%f", &vegetable.unit_price);

    printf("Quantity of Mineral Water: ");
    scanf("%d", &water.quantity);
    printf("Unit Price: ");
    scanf("%f", &water.unit_price);

    printf("Number of People: ");
    scanf("%d", &people);

    float total_bill = (paratha.quantity * paratha.unit_price) + 
                       (vegetable.quantity * vegetable.unit_price) + 
                       (water.quantity * water.unit_price);

    printf("Individual people will pay: %.2f tk\n", total_bill / people);
    return 0;
}
