#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    FILE *filePtr;
    char filename[100];
    char input[100];

    // Check if the user provided a filename as a command-line argument
    if (argc < 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    // Copy the filename from the command-line argument
    strcpy(filename, argv[1]);
    
    // Try opening the file in append mode; if it doesn't exist, it will be created
    filePtr = fopen(filename, "a");
    if (filePtr == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    printf("Enter strings to write to the file. Enter \"-1\" to stop.\n");

    // Continue to ask for strings and write them to the file
    while (1) {
        printf("Enter string: ");
        fgets(input, sizeof(input), stdin);  // Get user input
        input[strcspn(input, "\n")] = 0;  // Remove the newline character

        // If the user enters "-1", break the loop
        if (strcmp(input, "-1") == 0) {
            break;
        }

        // Write the input string to the file
        fprintf(filePtr, "%s\n", input);
    }

    // Close the file after finishing the writing
    fclose(filePtr);
    printf("Strings have been written to %s.\n", filename);

    return 0;
}

