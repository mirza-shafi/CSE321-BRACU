#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_SIZE sizeof(struct shared_memory)
#define PIPE_READ_END 0
#define PIPE_WRITE_END 1

struct shared_memory {
    char user_input[100];
    int balance;
};

int main() {
    int shared_mem_id;
    key_t shared_key = IPC_PRIVATE;
    struct shared_memory *shared_data;

    if ((shared_mem_id = shmget(shared_key, SHM_SIZE, IPC_CREAT | 0666)) < 0) {
        perror("shmget");
        exit(1);
    }

    shared_data = (struct shared_memory *)shmat(shared_mem_id, NULL, 0);
    if (shared_data == (struct shared_memory *)-1) {
        perror("shmat");
        exit(1);
    }

    int pipe_fd[2];
    if (pipe(pipe_fd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid_t process_id = fork();

    if (process_id == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (process_id == 0) { 
        close(pipe_fd[PIPE_WRITE_END]);

        char input_buffer[100];
        read(pipe_fd[PIPE_READ_END], input_buffer, sizeof(input_buffer));
        printf("Your selection: %s\n", input_buffer);

        int current_balance = shared_data->balance;

        if (strcmp(input_buffer, "a") == 0) {
            printf("Enter amount to be added:\n");
            int add_amount;
            scanf("%d", &add_amount);
            if (add_amount > 0) {
                current_balance += add_amount;
                shared_data->balance = current_balance;
                printf("Balance added successfully\nUpdated balance after addition:\n%d\n", current_balance);
            } else {
                printf("Adding failed, Invalid amount\n");
            }
        } else if (strcmp(input_buffer, "w") == 0) {
            printf("Enter amount to be withdrawn:\n");
            int withdraw_amount;
            scanf("%d", &withdraw_amount);
            if (withdraw_amount > 0 && withdraw_amount <= current_balance) {
                current_balance -= withdraw_amount;
                shared_data->balance = current_balance;
                printf("Balance withdrawn successfully\nUpdated balance after withdrawal:\n%d\n", current_balance);
            } else {
                printf("Withdrawal failed, Invalid amount\n");
            }
        } else if (strcmp(input_buffer, "c") == 0) {
            printf("Your current balance is:\n%d\n", current_balance);
        } else {
            printf("Invalid selection\n");
        }

        close(pipe_fd[PIPE_READ_END]);
        write(pipe_fd[PIPE_WRITE_END], "Thank you for using\n", strlen("Thank you for using\n") + 1);
        close(pipe_fd[PIPE_WRITE_END]);
        exit(EXIT_SUCCESS);
    } else { 
        close(pipe_fd[PIPE_READ_END]);

        printf("Provide Your Input From Given Options:\n1. Type a to Add Money\n2. Type w to Withdraw Money\n3. Type c to Check Balance\n");
        char user_selection[100];
        scanf("%s", user_selection);
        

        strcpy(shared_data->user_input, user_selection);
        shared_data->balance = 1000;

        write(pipe_fd[PIPE_WRITE_END], user_selection, strlen(user_selection) + 1);
        close(pipe_fd[PIPE_WRITE_END]);

        wait(NULL); 

        char output_buffer[100];
        read(pipe_fd[PIPE_READ_END], output_buffer, sizeof(output_buffer));
        printf("%s", output_buffer);

        close(pipe_fd[PIPE_READ_END]);

        printf("Thank you for using\n");


        shmdt(shared_data);
        shmctl(shared_mem_id, IPC_RMID, NULL);
    }

    return 0;
}

