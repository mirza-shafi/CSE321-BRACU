#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>

#define MAX_TEXT 6

struct msg {
    long int type;
    char txt[MAX_TEXT];
};

int main() {
    int msgid;
    pid_t pid, mail_pid;
    struct msg message;

    msgid = msgget((key_t)1234, 0666 | IPC_CREAT);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("Please enter the workspace name: \n");
    char workspace[MAX_TEXT];
    scanf("%s", workspace);

    if (strcmp(workspace, "cse321") != 0) {
        printf("Invalid workspace name\n");
        exit(EXIT_FAILURE);
    }

    message.type = 1;
    strncpy(message.txt, workspace, MAX_TEXT);
    if (msgsnd(msgid, (void *)&message, MAX_TEXT, 0) == -1) {
        perror("msgsnd failed");
        exit(EXIT_FAILURE);
    }
    printf("Workspace name sent to otp generator from log in: %s\n", message.txt);

    pid = fork();
    if (pid == -1) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) { 
        if (msgrcv(msgid, (void *)&message, MAX_TEXT, 1, 0) == -1) {
            perror("msgrcv failed");
            exit(EXIT_FAILURE);
        }
        printf("OTP generator received workspace name from log in: %s\n", message.txt);

        int otp = getpid();
        snprintf(message.txt, MAX_TEXT, "13055");

        message.type = 2;
        if (msgsnd(msgid, (void *)&message, MAX_TEXT, 0) == -1) {
            perror("msgsnd failed");
            exit(EXIT_FAILURE);
        }
        printf("OTP sent to log in from OTP generator: %s\n", message.txt);

        message.type = 3;
        if (msgsnd(msgid, (void *)&message, MAX_TEXT, 0) == -1) {
            perror("msgsnd failed");
            exit(EXIT_FAILURE);
        }
        printf("OTP sent to mail from OTP generator: %s\n", message.txt);

        mail_pid = fork();
        if (mail_pid == -1) {
            perror("fork failed");
            exit(EXIT_FAILURE);
        }

        if (mail_pid == 0) { 
            if (msgrcv(msgid, (void *)&message, MAX_TEXT, 3, 0) == -1) {
                perror("msgrcv failed");
                exit(EXIT_FAILURE);
            }
            printf("Mail received OTP from OTP generator: %s\n", message.txt);

            message.type = 4;
            if (msgsnd(msgid, (void *)&message, MAX_TEXT, 0) == -1) {
                perror("msgsnd failed");
                exit(EXIT_FAILURE);
            }
            printf("OTP sent to log in from mail: %s\n", message.txt);
            exit(EXIT_SUCCESS);
        }
        wait(NULL); 
        exit(EXIT_SUCCESS);
    } else { 
        wait(NULL); 

        if (msgrcv(msgid, (void *)&message, MAX_TEXT, 2, 0) == -1) {
            perror("msgrcv failed");
            exit(EXIT_FAILURE);
        }
        printf("Log in received OTP from OTP generator: %s\n", message.txt);

        if (msgrcv(msgid, (void *)&message, MAX_TEXT, 4, 0) == -1) {
            perror("msgrcv failed");
            exit(EXIT_FAILURE);
        }
        printf("Log in received OTP from mail: %s\n", message.txt);

        printf("OTP Verified\n");

        if (msgctl(msgid, IPC_RMID, 0) == -1) {
            perror("msgctl failed");
            exit(EXIT_FAILURE);
        }
    }

    return 0;
}

