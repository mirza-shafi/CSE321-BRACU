#include <stdio.h>
#include <string.h>
#include <ctype.h>
int has_lowercase(const char *input) {
    for (int i = 0; input[i] != '\0'; i++) {
        if (islower(input[i])) {
            return 1;
        }
    }
    return 0;
}

int has_uppercase(const char *input) {
    for (int i = 0; input[i] != '\0'; i++) {
        if (isupper(input[i])) {
            return 1;
        }
    }
    return 0;
}

int has_digit(const char *input) {
    for (int i = 0; input[i] != '\0'; i++) {
        if (isdigit(input[i])) {
            return 1;
        }
    }
    return 0;
}

int has_special_character(const char *input) {
    const char *special_chars = "_,$#@";
    for (int i = 0; input[i] != '\0'; i++) {
        if (strchr(special_chars, input[i]) != NULL) {
            return 1;
        }
    }
    return 0;
}

void validate_password(const char *input) {
    int contains_lowercase = has_lowercase(input);
    int contains_uppercase = has_uppercase(input);
    int contains_digit = has_digit(input);
    int contains_special_char = has_special_character(input);

    if (!contains_lowercase) {
        printf("Lowercase character missing\n");
    }
    if (!contains_uppercase) {
        printf("Uppercase character missing\n");
    }
    if (!contains_digit) {
        printf("Digit missing\n");
    }
    if (!contains_special_char) {
        printf("Special character missing\n");
    }

    if (contains_lowercase && contains_uppercase && contains_digit && contains_special_char) {
        printf("OK\n");
    }
}

int main() {
    char user_input[100];

    printf("Input: ");
    fgets(user_input, sizeof(user_input), stdin);
    
    if (user_input[strlen(user_input) - 1] == '\n') {
        user_input[strlen(user_input) - 1] = '\0';
    }

    printf("Output:\n");
    validate_password(user_input);

    return 0;
}

