#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void remove_extra_spaces(char *input, char *output) {
    FILE *input_file = fopen(input, "r");
    FILE *output_file = fopen(output, "w");
    char line[1000], word[100];

    if (input_file == NULL || output_file == NULL) {
        printf("Error\n");
        exit(1);
    }

    while (fgets(line, sizeof(line), input_file)) {
        char *token = strtok(line, " ");
        while (token != NULL) {
            fprintf(output_file, "%s ", token);
            token = strtok(NULL, " ");
        }
        fprintf(output_file, "\n");
    }

    fclose(input_file);
    fclose(output_file);
}

int main() {
    remove_extra_spaces("input_2b.txt", "output_2b.txt");
    return 0;
}

